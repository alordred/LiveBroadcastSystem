
#include "QtAV/%CLASS%.h"
#include "private/%CLASS%_p.h"

namespace QtAV {

%CLASS%::%CLASS%(%CLASS%Private &d):
    DPTR_INIT(&d)
{
}

} //namespace QtAV
