
#ifndef QTAV_%CLASS:u%_P_H
#define QTAV_%CLASS:u%_P_H

#include "private/%BASE%_p.h"

namespace QtAV {

class Q_AV_PRIVATE_EXPORT %CLASS%Private : public %BASE%Private
{
public:
    virtual ~%CLASS%Private() {}
};

} //namespace QtAV

#endif // QTAV_%CLASS%_P_H
