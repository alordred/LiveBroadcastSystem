
#include "QtAV/%CLASS%.h"
#include "private/%CLASS%_p.h"

namespace QtAV {

%CLASS%::%CLASS%(%CLASS%Private &d):
    %BASE%(d)
{
}

%CLASS%::~%CLASS%()
{
}

} //namespace QtAV
