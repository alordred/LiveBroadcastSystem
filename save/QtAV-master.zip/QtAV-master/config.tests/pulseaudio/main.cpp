#include <pulse/pulseaudio.h>

int main()
{
    return 0;
}
